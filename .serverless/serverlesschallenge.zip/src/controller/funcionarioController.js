import Funcionario from "../domain/funcionario";
import CreateFuncionario from "../usecase/createFuncionario";
import * as funcionarioRepository from "../repository/mysqlRepository";

const createFuncionarioUseCase = new CreateFuncionario(funcionarioRepository);

export async function createFuncionario(body) {
    const funcionarioData = body;
    const funcionario = new Funcionario(funcionarioData.nome, funcionarioData.idade, funcionarioData.cargo);
    const novoFuncionario = await createFuncionarioUseCase.execute(funcionario);
    return novoFuncionario;
}