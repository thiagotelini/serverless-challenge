export function createFuncionario(funcionario) {
    
}